# MarsWalk TODO

The working list for what comes next. Three parts: making the models more like Mars, making the game engine faster,
and the two easter eggs. Every item says why it matters, how to do it (data, formula, files), and how we will know it
is done. Ticked items are built and tested.

Rules that every item keeps:

- **One model, two places.** A change to how walking, oxygen or terrain works goes into the planner first
  (`src/marswalk/cost/physics.py` and friends), then into the simulator's copy (`frontend/src/sim/physics.ts`), and the
  parity check (TypeScript against Python on the same inputs) is rerun. The simulator never gets physics of its own.
- **Numbers come from data or are labelled as assumptions** in `configs/`, with the source next to them.
- **Every new number gets a check** in `marswalk audit` or in the tests.

Priority: **P1** changes what a crew would decide; **P2** makes the numbers more trustworthy; **P3** makes it feel
more like Mars.

---

## 1. Realism: the models

### Done

- [x] **The simulator walks on the planner's own model.** 1 m walk surface, roughness, sand and off-limits from the
  layer stack (`/api/sim/fine.bin`); speed, terrain multiplier and power step for step; grades over 20° cannot be
  walked. 1,440 sampled steps identical to `edge_time_energy`.
- [x] **The real Sun.** Mars24 (Allison & McEwen 2000) in `src/marswalk/sun.py`, tested against both NASA GISS worked
  examples to 0.001°. Walk starts at `[eva] start_lmst_h`.

### P1: changes what a crew would decide

- [ ] **Walking at 0.38 g: the gait limit.** The speed curve (Marquez) allows 1.6 m/s on the flat. People switch from
  walking to running near a Froude number of about 0.5, and Fr = v² / (g L) means that switch comes at a lower speed
  in lower gravity: about √(0.5 × 3.71 × 0.9) ≈ 1.3 m/s on Mars for a 0.9 m leg. Above that, a suited walker lopes,
  as on the Moon, with a different energy cost.
  - How: add a `gait` step to `walk_speed_mps`: below the transition, today's curve; above it, a loping model. Put
    the transition Froude number and leg length in `configs/eva`.
  - Data: Kram, Domingo & Ferris 1997 (J. Exp. Biol.) on the walk-run transition in reduced gravity; Apollo EVA
    traverse rates; NASA reduced-gravity suited walking studies (planetary-suit ambulation, e.g. NASA/TP-2010-216115).
  - Done when: the audit compares predicted speed and power at 0.38 g against at least one published dataset, and
    the plan, the safe zone and the simulator all change together.
- [ ] **Metabolic cost measured at Mars gravity.** Today the level-walking term is Santee's Earth formula scaled by
  g / g_Earth: a MarsWalk assumption, flagged as one. Replace or calibrate it with reduced-gravity suited data (same
  sources as above). Keep the old model selectable for comparison.
- [ ] **The consumable that runs out first.** Oxygen is rarely the limit in a modern suit; cooling water or CO₂ removal
  often is. Track water (heat to reject = metabolic heat + sunlight + ground infrared), CO₂ scrubber capacity and
  battery (`battery_capacity_wh` is in the config already, unused).
  - How: a `consumables` module that returns time left per consumable; the binding one drives "turn back within".
  - Data: published xEMU / exploration suit requirements; the thermal inputs below.
  - Done when: the status report and the suit display name the limiting consumable.
- [ ] **Radio shadow.** Behind a ridge the crew cannot talk to the rover. Compute the viewshed from the rover's antenna
  height over the DTM; show radio-shadow ground on the map, warn when the route enters it, add "time out of contact".
  - How: horizon scan per azimuth on the 1 m DEM (numba), cached like the walk-home field.
- [ ] **Shelter time for a solar storm.** DONKI already gives warnings. Compare the warning lead time of a solar
  particle event with the walk home from every point; mark ground from which the crew could not get back in time.

### P2: makes the numbers more trustworthy

- [ ] **Uncertainty in the terrain.** HiRISE stereo DTMs have a vertical precision of tens of centimetres and our
  registration fix has its own error. Run the slope and off-limits masks on perturbed DTMs (Monte Carlo, ~20 draws),
  and show off-limits ground as "always", "sometimes", "never". Route on the "sometimes" class with a penalty.
  - Data: the DTM's own precision estimate in its PDS label; the registration residual from `coverage.py`.
- [ ] **Sand that is more than yes/no.** Replace the thermal-inertia threshold (300) with a continuous model:
  thermal inertia → grain size (Presley & Christensen 1997) → boot sinkage and slip (Bekker–Wong terramechanics),
  feeding a continuous multiplier instead of ×1.2.
  - Done when: the sand multiplier varies smoothly and the audit shows its range on this site (currently no ground is
    below the threshold: TI here is 317 or more).
- [ ] **Rocks you can count.** The 25 cm orthophoto is already in the config as optional (`ortho_25cm`). Detect
  boulders (shadow-based detection, as in HiRISE rock-count studies), add a rock-abundance layer, and use it in
  roughness and off-limits. Rocks also become 3-D objects in the simulator (see E6).
- [ ] **Dust in the air.** Dust opacity (tau) sets how bright the Sun is, how blue the sky is near it, how soft shadows
  are and how far you can see. Curiosity measures tau at Gale with Mastcam.
  - How: a tau-by-season table for Gale (`configs/sites`), then in the simulator: direct light ∝ exp(−tau / sin el),
    diffuse light rising with tau, fog density from tau. In the planner: a "low light" flag for low Sun and high tau.
  - Data: Mastcam tau records (PDS Atmospheres node; Lemmon et al.).
- [ ] **Temperature.** Ground and air temperature through the sol change the suit's heat load (P1 consumables).
  - Data: Curiosity REMS (PDS Atmospheres node), or the Mars Climate Database by Ls, local time and location.
- [ ] **Radiation that changes.** The RAD dose rate at the surface depends on the air above (it rises when pressure
  drops) and on the solar cycle. Replace the constant 0.21 mGy/day with a function of season (pressure from REMS)
  and solar activity, keep DONKI for events.
- [ ] **Validation against people.** Compare planned times with analog field campaigns (BASALT, Desert RATS) to tune
  `time_margin_factor` (1.3 today) from data, not from one lesson.

### P3: makes it feel more like Mars

- [ ] **True colour.** HiRISE has a colour strip (IRB) that covers S2 only (`ortho_color_1m`, optional). Use it where it
  exists and calibrate the tint elsewhere against Mastcam colour images of the same area.
- [ ] **Sound.** Mars air is thin: sound is quieter, high pitches fade fast, and Perseverance's microphones measured a
  speed of sound of about 240 m/s. Game audio: footsteps through the suit (loud), the outside world through a strong
  low-pass filter, the rover's radio for voice.
- [ ] **Wind and dust devils.** REMS wind and dust-devil counts at Gale by season; a dust devil crossing the route is
  a warning, not a hazard model, until we have data on suits in one.
- [ ] **Mission clock.** Show the mission sol and local true solar time (Mars24 gives both) on the suit display.
- [ ] **Local gravity.** Gravity models (e.g. GMM-3) vary by a fraction of a percent across a site this small.
  Compute it once, show it is negligible, close the item.

---

## 2. The game engine

### Done (this round)

- [x] **Terrain in tiles with frustum culling.** `Terrain.chunks(64)` splits the 3 m ground into 64 × 64-cell tiles
  (48 tiles here; about half are out of view at a time); three.js skips tiles outside the view. Normals come from the whole grid, so tiles meet without
  seams. The off-limits overlay shares the tile geometry.
- [x] **Adaptive resolution.** Every second the engine averages frame time: over 24 ms (under ~40 fps) it renders
  fewer pixels (down to ×0.6); under 14 ms it sharpens back up to the screen's ratio.
- [x] **Shadows only when something moved.** The shadow map is redrawn when the walker, the board or the Sun moves (or
  the alien is animating nearby), not every frame. Standing still costs no shadow pass.
- [x] **No garbage per frame.** Colours, vectors, the frustum and matrices used every frame are reused.
- [x] **The 1 m walking grid stays 16-bit.** 3 MB instead of a 6 MB float copy (copied only on big-endian machines).
- [x] **Engine statistics.** Press **F**: fps, frame time, draw calls, triangles, ground tiles in view, resolution,
  shadow redraws per second.
- [x] **The simulator is its own bundle**, loaded only when you press Simulation.
- [x] **Checked in QA** (headless, software rendering): 26 of 48 tiles drawn in a typical view, 0 shadow redraws over
  20 still frames and 1 after a 1 m move, resolution dropped to ×0.6 at software-rendering frame times.

### Next

- [ ] **E1. Level of detail for the ground.** Near the walker, draw the 1 m grid (we already ship it); far away,
  coarser tiles (3 m, 6 m, 12 m) with skirts to hide cracks. Geomipmapping per tile is enough; CDLOD if we go bigger.
  Done when: 1 m detail within ~100 m, and triangle count stays under today's.
- [ ] **E2. A Web Worker for the heavy lifting.** Decoding the grids, building tile geometry and finding the easter-egg
  spot block the main thread for a moment at start. Move them to a worker and send the buffers back as transferables.
- [ ] **E3. Binary heights.** `/api/sim/terrain` sends heights as base64 inside JSON (33 % bigger, slower to parse).
  Serve them like `fine.bin`.
- [ ] **E4. Compressed textures.** The photo is a PNG decoded to raw RGBA on the GPU. KTX2/Basis cuts GPU memory about
  four-fold; add mipmaps for the minimap too.
- [ ] **E5. Lighting detail from 1 m normals.** A normal map baked from the 1 m DTM would show 1 m relief on the 3 m
  mesh under the real Sun. Catch: the HiRISE photo already has the shading of the moment it was taken baked in. Either
  remove that shading from the photo first or blend the two gently; test both by eye at low Sun.
- [ ] **E6. Instanced rocks.** When the boulder layer exists (realism P2), draw rocks with `InstancedMesh` (a few
  shapes, many copies), with impostors far away.
- [ ] **E7. Cascaded shadow maps.** Today one 80 m shadow box follows the walker. Low Sun throws long shadows; split
  into 2 to 3 cascades so nearby shadows stay sharp and far ones exist.
- [ ] **E8. Fixed time step.** Physics already steps in 0.5 s slices of mission time; decouple it fully from the frame
  rate with an accumulator and interpolate the drawn position.
- [ ] **E9. A lighter HUD.** The status emits every 150 ms and React re-renders the whole HUD. Move status into a small
  external store (`useSyncExternalStore`), redraw the minimap only when the walker moved a pixel.
- [ ] **E10. Sleep when nothing changes.** While paused or in the debrief, render once and stop the loop.
- [ ] **E11. Real-GPU numbers in QA.** The headless QA uses software rendering (about 2 fps). Record a frame-time
  histogram on a real GPU (a laptop run with `?perf=1`) and keep it in the repo as the baseline.
- [ ] **E12. WebGPU.** three.js ships a WebGPU renderer; try it once E1 to E4 are in.

---

## 3. Easter eggs

Both are off-plan: they never change the plan, oxygen keeps counting, and the debrief says when they were used.

### [x] Perseverance and the cardboard Mars

![Perseverance photographing the cardboard Mars](docs/img/sim-perseverance.png)

Somewhere off the route, Perseverance (officially near Jezero crater, about 3,800 km from Gale) has its mast camera
trained on a cardboard picture of Mars. An alien is holding it up for the photo.

- **Where:** `WalkGrid.findQuietSpot()` picks the flattest walkable ground 150 to 320 m from the rover and at least
  90 m from every stop and the route. The same terrain always gives the same spot. No map marker: you find it by
  looking around (the alien's antennae glow).
- **What happens:** within 30 m the alien peeks over the sign and turns its head to follow you. Within 12 m, **E** says
  hi: it lowers the sign and waves. It counts in the debrief ("Easter eggs found").
- **Models** (`frontend/src/sim/eggs.ts`): Perseverance from simple shapes at its real size (about 3 m long, six
  52.5 cm wheels, rocker-bogie, RTG at the back, mast head with SuperCam and the Mastcam-Z pair, folded arm). The mast
  head is aimed at the sign with `lookAt`; QA checks it points within 2°. The alien is our own design (teal, three
  eyes, two glowing antennae). The picture is drawn in code on a canvas: sky, Sun, a mesa, dunes, tape, and "MARS (real)"
  in marker.
- **Ideas:** the rover's camera view on a little screen (render-to-texture from the mast head); a photo mode.

### [x] Skateboarding on Mars

![Skateboarding near the rover](docs/img/sim-skateboard.png)

A skateboard lies a few steps to the right of the crew rover. **E** picks it up, **B** gets on and off.

- **Controls on the board:** W push, S brake (foot drag), A/D lean to turn, Space ollie (the same hop physics: 0.86 s
  in the air at 3.71 m/s²), B step off.
- **Physics** (`frontend/src/sim/skate.ts`, all per 0.5 s or finer slice of mission time, on the planner's 1 m ground):
  - downhill pull: g sin(grade), g = 3.71 m/s² (a 10° slope gives 0.50 m/s² after rolling resistance; checked)
  - rolling resistance: C_rr × g cos(grade), with C_rr = 0.04 on smooth firm ground, + 0.3 per metre of the planner's
    roughness, + 0.25 on loose sand (assumptions for small urethane wheels on regolith; capped at 0.8)
  - air drag: ½ ρ C_d A v² with ρ = 0.02 kg/m³: 0.2 N at 5 m/s against 21 N of rolling resistance. On Mars the air
    does nothing; the ground does everything.
  - pushing: at most 60 N (only 0.38 g holds your foot down) and 100 W of mechanical power; metabolic power = 60 W
    rest + push power / 0.25
  - braking: 1.5 m/s² (friction-limited: 0.6 × 3.71 = 2.2 at best)
  - what you get: about 4.7 m/s top speed pushing on smooth ground, about 2 m/s on typical ground here (0.17 m
    roughness), nothing on sand; coasting from 3 m/s on the flat lasts about 20 s
  - wipeouts: speed wobbles over 7 m/s, or rocky (off-limits) ground at over 1.2 m/s. You come off the board.
- **Accounting:** time, oxygen and energy keep counting (the push costs real effort); distance on the board is logged
  separately and shown in the debrief as off-plan. A blue banner says you are off-plan while riding.
- **Ideas:** trick scoring for ollies off ledges (airtime is long at 0.38 g); a downhill run timer from the top of the
  boxwork ridge; dust plume from the wheels.

### How to add another egg

1. Model in `eggs.ts` (own design only: no characters or logos from anywhere else).
2. Place it in `SimEngine.placeEggs()` with a deterministic rule on the walking grid.
3. Reach and prompt in `checkEggs()`, action in `act()`, animation in `animateEggs()`.
4. Count it in `status.eggsFound` (and the "of N" in the debrief), and add a QA check in the headless run.
