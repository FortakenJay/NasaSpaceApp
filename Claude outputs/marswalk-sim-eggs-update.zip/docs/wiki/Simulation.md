# Simulation

A plan on a map is a promise. The simulator lets a crew member keep it with their own hands first: walk the planned
route, on the real ground at Gale crater, under Mars gravity, while the suit's oxygen drains at the rate the planner
predicted. Plan a route, then press **Simulation** in the header. The simulator walks the route on screen; without
one you can still explore the ground, but there is no route line, suit display or debrief comparison.

![Walking the planned route after finishing S1](../img/sim-walk.png)

## What is on the screen

| Where | What it shows |
|---|---|
| Top left | Mission time, local solar time at the rover, and the time speed (×1, ×5, ×20, ×60) |
| Left | **Status report**: oxygen before the reserve, walk home, turn back within, distance walked, effort and oxygen breathed, radiation dose so far, where the Sun is in the sky, space weather, gravity, pace (speed, grade, power) and the ground under your boots with how much it slows you |
| Top right | **Minimap**, north up, on the HiRISE photo: route, stops, rover and you |
| Right | **How far is everything**: each stop and the rover, with distance and compass direction; the next stop is marked, finished stops say "done" |
| Bottom left | **The suit display**, the same e-ink screen the ESP32 shows, redrawn from your live position once per minute of mission time (the ESP32 downloads it once a minute) and whenever you finish a stop. Click it to enlarge |
| Bottom | **Ask**: type or press the microphone. Answers use where you are standing and which stops you have done |

## Controls

| Key | Action |
|---|---|
| W / S | Walk forward / back (backwards at half speed) |
| A / D | Turn |
| Space | Hop |
| E | Work at a stop (inside its amber ring), or end the walk at the rover |
| T | Time speed ×1, ×5, ×20, ×60 |
| V | First or third person |
| H | Show off-limits ground |
| M | Minimap zoom |
| / | Ask a question (or use the microphone) |
| Drag · wheel | Look around · zoom |
| Esc | Pause |
| F | Engine statistics: fps, draw calls, triangles, ground tiles in view, resolution, shadow redraws |
| ? | Help |

## What is real

Nothing in the simulator has physics of its own. It runs the planner's models on the planner's data, step for step,
so what you feel is what the plan assumed.

- **The ground under your boots.** The physics reads the planner's own 1 m grid: the walking surface the route search
  takes its grades from, roughness, loose sand (from THEMIS thermal inertia) and the off-limits mask, cell for cell
  (`GET /api/sim/fine.bin`). A test checks that each stop's cell holds the same values as the route search's layers.
- **Your speed.** Every half second of mission time, the engine reads the grade one metre ahead along your heading on
  that walking surface and sets your speed from the planner's speed-versus-slope curve (1.6 m/s on the flat at most).
  Rough ground stretches the time by 1 + 2 × roughness in metres, loose sand by another ×1.2, exactly as the route
  search prices a step. The speed applies along the slope, so a climb also covers less ground on the map. You cannot
  outrun the plan by holding W.
- **The 20° limit.** A grade the planner will not route over cannot be walked: you stop, and the screen says how steep
  it is and that you need another way.

  ![A 21° slope stops the walker; the ground readout shows rough ground slowing each step ×2.2](../img/sim-too-steep.png)

- **Your oxygen.** Power comes from the same metabolic model as the planner (Santee, scaled to Mars gravity), at the
  same crew and suit mass, taken at the model speed while the terrain multiplier stretches the time, which is how the
  planner charges rough ground. Standing still costs resting power (60 W); working at a stop costs 250 W; a hop costs
  the energy of lifting you and the suit, at 25 % muscle efficiency. The oxygen gauge counts down the 8-hour tank minus
  the 30 % reserve, in mission time.
- **Gravity.** 3.71 m/s². A hop at 1.6 m/s takes 2v/g = 0.86 s and rises v²/2g = 0.35 m, and the QA run measures
  exactly that.
- **The Sun.** The light comes from where the Sun really will be at the rover. The walk starts at the next 09:00 local
  mean solar time (`start_lmst_h` in `configs/eva`), and NASA GISS's Mars24 algorithm (Allison & McEwen 2000) gives the
  Sun's azimuth and elevation every 2 minutes from there. The code reproduces both of NASA's published worked examples
  to within 0.001°. Shadows fall the right way, the Sun climbs toward local noon, and a low Sun turns the sky around it
  blue, as Martian sunsets do. The screen shows the local time and the Sun's height and direction.
- **The walk home.** The status report asks the API the same question as the planner's safe zone: from here, with
  the time used so far, how long is the walk home, and how long can you keep going before you must turn back.
- **Space weather.** The same DONKI go/no-go as the planner, and the dose from Curiosity's RAD rate at Gale.

## What is not

- **What you see is smoother than what you walk on.** The 3-D mesh averages heights into 3 m blocks so a laptop can
  draw it; single boulders and short ledges are not in the picture. The physics still uses the full 1 m grid, so a
  ledge you cannot see still slows or stops you.
- **The colours are not true colour.** HiRISE photographs this area in one red band; the simulator tints it to Mars
  colours. The sky colours are an artist's choice, not a radiative model.
- **No weather.** No dust storms, wind or temperature. The planner has no model of them either.
- **The suit is a figure, not a suit model.** No joint limits, fatigue or falls. Walking backwards at half speed is
  the simulator's own choice; the planner never plans a backwards step.
- **Off-limits ground warns, it does not stop you.** Time spent on it is logged and shown in the debrief. Grades over
  20° do stop you.
- **Gale only.** The ground, photo, radiation rate and registration fix are measured for this site. A new site needs its
  own site file and HiRISE terrain model; the code is the same.

## The debrief

End the walk at the rover with E, or run the tank dry, and the debrief compares you with the plan: stops done,
distance, time outside, effort, oxygen left before the reserve, and time on off-limits ground. It ends one of three
ways: *Walk complete*, *Back, but into the reserve*, or *Out of oxygen*.

![The debrief after a short walk to S1 and back](../img/sim-debrief.png)

## How it was checked

A headless browser drives the game with the keyboard and steps the engine in fixed mission time, then checks 33
things against the models (including the engine optimizations and the easter eggs; see `TODO.md`). From the last run:

| Check | Result |
|---|---|
| Every step against the planner's edge model (speed, power, terrain multiplier), 1,440 steps on varied ground | Identical (largest difference 0), ground from ×1.06 to ×2.26 slower |
| Walking 402 s of mission time toward S1 | 186 m at 0.46 m/s average, never above 1.6 m/s |
| Average power while walking | 205 W, inside the model's 60–450 W |
| A 21° grade on the walking surface | Stopped, 0.000 m moved, "Too steep to walk" shown |
| The Sun at the start | 36.7° up at azimuth 74.5° (east-northeast), 09:00 local, Ls 22° |
| The Sun 3 h later | 73.8° up, near local noon |
| 30 min of work at S1 at 250 W (450 kJ expected) | 458 kJ over 32.1 min |
| Hop under 3.71 m/s² (0.862 s and 0.345 m expected) | 0.860 s and 0.341 m |
| Suit display | Redraws within a mission minute; after S1 it points to S2 from the live position |
| Live question after S1 | "S2 (First boxwork ridge stop) is 420 m from your position in a straight line" |
| Off-limits ground | Warning shown and time logged |
| Ending at the rover / running dry | "Walk complete" / "Out of oxygen" |

The TypeScript physics was also run against the Python on seven test steps (flat, climbs, descents, rough, sand, and
just past 20°): time and energy agree to the last digit. The sand multiplier is tested but never comes into play on
this walk: THEMIS thermal inertia in this window never drops below 317, and MarsWalk calls ground loose sand below 300.

The test ran in software rendering (no GPU), so the frame rate on a real laptop will be much higher than what the
test saw. The microphone could not be tested in the headless browser; the typed question goes through the same path.

## Easter eggs

There are two. Neither touches the plan; oxygen keeps counting and the debrief says when they were used. Where they
are and how they work (with spoilers) is in [`TODO.md`](../../TODO.md#3-easter-eggs).

## Under the hood

- `GET /api/sim/terrain?step=3` returns the heights (16-bit centimetres, base64), the off-limits bits, the local
  frame (east and south metres from the rover) and the physics constants from `configs/`.
- `GET /api/sim/texture.png?kind=photo|hazard` returns the ground photo or the off-limits overlay, on the same grid.
- `GET /api/sim/fine.bin` returns the 1 m walking grid the physics reads (gzip): walk-surface heights, roughness, sand
  and off-limits bits. Its shape and frame are in `/api/sim/terrain` under `fine`.
- `GET /api/sim/sun?start_utc=&hours=` returns the Sun's azimuth and elevation through the walk (`src/marswalk/sun.py`,
  Mars24, tested against NASA's worked examples in `tests/test_sun.py`).
- `/api/eink.png` and `/api/ask` accept the live position (`lat`, `lon`, or `here_lat`, `here_lon`), the distance
  walked, the energy used and the stops done.
- The frontend code is in `frontend/src/sim/`: `terrain.ts` (the 3 m mesh and the 1 m walking grid), `physics.ts` (the speed,
  power and terrain models, identical to the Python), `astronaut.ts`, `engine.ts` (Three.js scene and the
  mission-time loop) and `SimulationView.tsx` (the heads-up display). The simulator loads only when you open it, so it
  adds nothing to the planner's start-up.
