// A suited crew member built from simple shapes (about 1.85 m tall), with a walk cycle.
import * as THREE from 'three';

export interface Astronaut {
  group: THREE.Group;
  /** phase: radians of the stride cycle; moving: walking or not; airborne: mid-jump; skating: riding a board. */
  animate: (phase: number, moving: boolean, airborne: boolean, skating?: boolean) => void;
}

export function makeAstronaut(): Astronaut {
  const suit = new THREE.MeshStandardMaterial({ color: 0xf2efe8, roughness: 0.85 });
  const trim = new THREE.MeshStandardMaterial({ color: 0xb4b7bb, roughness: 0.6, metalness: 0.15 });
  const stripe = new THREE.MeshStandardMaterial({ color: 0xd2562f, roughness: 0.7 });
  const visor = new THREE.MeshStandardMaterial({ color: 0xc9902a, roughness: 0.15, metalness: 0.9 });
  const group = new THREE.Group();
  const body = new THREE.Group();
  group.add(body);

  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.27, 0.45, 6, 12), suit);
  torso.position.y = 1.22;
  body.add(torso);
  const band = new THREE.Mesh(new THREE.CylinderGeometry(0.285, 0.285, 0.07, 16), stripe);
  band.position.y = 1.05;
  body.add(band);
  const pack = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.62, 0.26), trim);
  pack.position.set(0, 1.28, 0.27);
  body.add(pack);
  const helmet = new THREE.Mesh(new THREE.SphereGeometry(0.2, 20, 16), suit);
  helmet.position.y = 1.7;
  body.add(helmet);
  const face = new THREE.Mesh(new THREE.SphereGeometry(0.17, 20, 12, Math.PI * 0.6, Math.PI * 0.8, Math.PI * 0.3, Math.PI * 0.4), visor);
  face.position.set(0, 1.71, -0.04);
  body.add(face);

  const limb = (r: number, len: number, mat: THREE.Material) => {
    const pivot = new THREE.Group();
    const m = new THREE.Mesh(new THREE.CapsuleGeometry(r, len, 4, 10), mat);
    m.position.y = -len / 2 - r;
    pivot.add(m);
    return pivot;
  };
  const legL = limb(0.1, 0.62, suit);
  const legR = limb(0.1, 0.62, suit);
  legL.position.set(-0.13, 0.9, 0);
  legR.position.set(0.13, 0.9, 0);
  const armL = limb(0.075, 0.5, suit);
  const armR = limb(0.075, 0.5, suit);
  armL.position.set(-0.36, 1.5, 0);
  armR.position.set(0.36, 1.5, 0);
  for (const b of [legL, legR]) {
    const boot = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.1, 0.28), trim);
    boot.position.set(0, -0.86, -0.05);
    b.add(boot);
  }
  body.add(legL, legR, armL, armR);
  group.traverse((o) => {
    if (o instanceof THREE.Mesh) o.castShadow = true;
  });

  return {
    group,
    animate(phase, moving, airborne, skating = false) {
      if (skating) {
        // sideways stance, knees bent, arms out for balance
        body.rotation.y = Math.PI / 2;
        body.position.y = 0.1 - 0.08;
        legL.rotation.set(0, 0, 0.18);
        legR.rotation.set(0, 0, -0.18);
        armL.rotation.set(0, 0, -0.9 + Math.sin(phase) * 0.08);
        armR.rotation.set(0, 0, 0.9 - Math.sin(phase) * 0.08);
        return;
      }
      body.rotation.y = 0;
      legL.rotation.z = 0;
      legR.rotation.z = 0;
      armL.rotation.z = 0;
      armR.rotation.z = 0;
      const swing = airborne ? 0.35 : moving ? Math.sin(phase) * 0.5 : 0;
      legL.rotation.x = swing;
      legR.rotation.x = airborne ? -0.2 : -swing;
      armL.rotation.x = -swing * 0.7;
      armR.rotation.x = airborne ? -0.6 : swing * 0.7;
      body.position.y = moving && !airborne ? Math.abs(Math.cos(phase)) * 0.05 : 0; // the low-gravity lope
    },
  };
}

/** The pressurized rover: the start and finish of every walk. */
export function makeRover(): THREE.Group {
  const g = new THREE.Group();
  const white = new THREE.MeshStandardMaterial({ color: 0xe9e6df, roughness: 0.6 });
  const dark = new THREE.MeshStandardMaterial({ color: 0x2c2f33, roughness: 0.9 });
  const glass = new THREE.MeshStandardMaterial({ color: 0x23364a, roughness: 0.1, metalness: 0.6 });
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(3.2, 1.7, 5.2), white);
  cabin.position.y = 1.65;
  g.add(cabin);
  const nose = new THREE.Mesh(new THREE.BoxGeometry(2.9, 1.0, 0.5), glass);
  nose.position.set(0, 1.95, -2.7);
  g.add(nose);
  for (const x of [-1.75, 1.75]) {
    for (const z of [-1.8, 0, 1.8]) {
      const w = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.45, 18), dark);
      w.rotation.z = Math.PI / 2;
      w.position.set(x, 0.55, z);
      g.add(w);
    }
  }
  const mast = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.6, 8), dark);
  mast.position.set(1.1, 3.3, 1.6);
  g.add(mast);
  const dish = new THREE.Mesh(new THREE.CircleGeometry(0.45, 20), white);
  dish.position.set(1.1, 4.1, 1.6);
  dish.rotation.x = -Math.PI / 3;
  g.add(dish);
  g.traverse((o) => {
    if (o instanceof THREE.Mesh) o.castShadow = true;
  });
  return g;
}
