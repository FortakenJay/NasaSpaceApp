// The walk area from GET /api/sim/terrain: heights and off-limits cells on a regular grid in local metres
// (origin at the rover, x east, z south, y up), and the conversion between local metres and lat/lon.
import * as THREE from 'three';
import type { SimFineMeta, SimTerrain } from '../api';

function b64(s: string): Uint8Array {
  const bin = atob(s);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export class Terrain {
  readonly rows: number;
  readonly cols: number;
  readonly heights: Float32Array; // metres relative to the rover
  readonly nogo: Uint8Array; // 1 = off-limits
  readonly t: SimTerrain;

  constructor(t: SimTerrain) {
    this.t = t;
    this.rows = t.rows;
    this.cols = t.cols;
    const raw = b64(t.heights_cm);
    const dv = new DataView(raw.buffer);
    this.heights = new Float32Array(t.rows * t.cols);
    for (let i = 0; i < this.heights.length; i++) this.heights[i] = t.h0 + dv.getUint16(i * 2, true) / 100;
    const bits = b64(t.nogo_bits);
    this.nogo = new Uint8Array(t.rows * t.cols);
    for (let i = 0; i < this.nogo.length; i++) this.nogo[i] = (bits[i >> 3] >> (7 - (i & 7))) & 1;
  }

  toLocal(lat: number, lon: number): { x: number; z: number } {
    return { x: (lon - this.t.lon0) * this.t.kx, z: -(lat - this.t.lat0) * this.t.kz };
  }

  toLatLon(x: number, z: number): { lat: number; lon: number } {
    return { lat: this.t.lat0 - z / this.t.kz, lon: this.t.lon0 + x / this.t.kx };
  }

  /** Grid coordinates (fractional) of a local point. */
  private cell(x: number, z: number): { c: number; r: number } {
    return { c: (x - this.t.x0) / this.t.dx, r: (z - this.t.z0) / this.t.dz };
  }

  bounds(): { minX: number; maxX: number; minZ: number; maxZ: number } {
    const xa = this.t.x0;
    const xb = this.t.x0 + (this.cols - 1) * this.t.dx;
    const za = this.t.z0;
    const zb = this.t.z0 + (this.rows - 1) * this.t.dz;
    return { minX: Math.min(xa, xb), maxX: Math.max(xa, xb), minZ: Math.min(za, zb), maxZ: Math.max(za, zb) };
  }

  /** Ground height at a local point (bilinear). */
  heightAt(x: number, z: number): number {
    const { c, r } = this.cell(x, z);
    const c0 = Math.min(Math.max(Math.floor(c), 0), this.cols - 2);
    const r0 = Math.min(Math.max(Math.floor(r), 0), this.rows - 2);
    const fc = Math.min(Math.max(c - c0, 0), 1);
    const fr = Math.min(Math.max(r - r0, 0), 1);
    const h = this.heights;
    const i = r0 * this.cols + c0;
    const top = h[i] * (1 - fc) + h[i + 1] * fc;
    const bot = h[i + this.cols] * (1 - fc) + h[i + this.cols + 1] * fc;
    return top * (1 - fr) + bot * fr;
  }

  isNoGo(x: number, z: number): boolean {
    const { c, r } = this.cell(x, z);
    const ci = Math.round(c);
    const ri = Math.round(r);
    if (ci < 0 || ri < 0 || ci >= this.cols || ri >= this.rows) return true;
    return this.nogo[ri * this.cols + ci] === 1;
  }

  /**
   * The ground as square tiles of `size` cells (sharing their edge vertices), so three.js can skip every tile outside
   * the view (frustum culling). Normals come from the whole grid by central differences, so tiles meet without seams.
   */
  chunks(size = 64): THREE.BufferGeometry[] {
    const { rows, cols } = this;
    const { dx, dz } = this.t;
    const nrm = new Float32Array(rows * cols * 3);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const hl = this.heights[r * cols + Math.max(c - 1, 0)];
        const hr = this.heights[r * cols + Math.min(c + 1, cols - 1)];
        const hu = this.heights[Math.max(r - 1, 0) * cols + c];
        const hd = this.heights[Math.min(r + 1, rows - 1) * cols + c];
        const sx = (hr - hl) / (dx * (Math.min(c + 1, cols - 1) - Math.max(c - 1, 0)));
        const sz = (hd - hu) / (dz * (Math.min(r + 1, rows - 1) - Math.max(r - 1, 0)));
        const len = Math.hypot(sx, 1, sz);
        const i = (r * cols + c) * 3;
        nrm[i] = -sx / len;
        nrm[i + 1] = 1 / len;
        nrm[i + 2] = -sz / len;
      }
    }
    const out: THREE.BufferGeometry[] = [];
    for (let r0 = 0; r0 < rows - 1; r0 += size) {
      for (let c0 = 0; c0 < cols - 1; c0 += size) {
        const r1 = Math.min(r0 + size, rows - 1);
        const c1 = Math.min(c0 + size, cols - 1);
        const nr = r1 - r0 + 1;
        const nc = c1 - c0 + 1;
        const pos = new Float32Array(nr * nc * 3);
        const uv = new Float32Array(nr * nc * 2);
        const nn = new Float32Array(nr * nc * 3);
        for (let r = 0; r < nr; r++) {
          for (let c = 0; c < nc; c++) {
            const gi = (r0 + r) * cols + (c0 + c);
            const li = r * nc + c;
            pos[li * 3] = this.t.x0 + (c0 + c) * dx;
            pos[li * 3 + 1] = this.heights[gi];
            pos[li * 3 + 2] = this.t.z0 + (r0 + r) * dz;
            uv[li * 2] = (c0 + c + 0.5) / cols;
            uv[li * 2 + 1] = 1 - (r0 + r + 0.5) / rows;
            nn[li * 3] = nrm[gi * 3];
            nn[li * 3 + 1] = nrm[gi * 3 + 1];
            nn[li * 3 + 2] = nrm[gi * 3 + 2];
          }
        }
        const idx = new Uint32Array((nr - 1) * (nc - 1) * 6);
        let k = 0;
        for (let r = 0; r < nr - 1; r++) {
          for (let c = 0; c < nc - 1; c++) {
            const a = r * nc + c;
            const d = a + nc;
            idx[k++] = a;
            idx[k++] = d;
            idx[k++] = a + 1;
            idx[k++] = a + 1;
            idx[k++] = d;
            idx[k++] = d + 1;
          }
        }
        const g = new THREE.BufferGeometry();
        g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
        g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
        g.setAttribute('normal', new THREE.BufferAttribute(nn, 3));
        g.setIndex(new THREE.BufferAttribute(idx, 1));
        g.computeBoundingSphere();
        out.push(g);
      }
    }
    return out;
  }

  /** The ground as one mesh (kept for tools and tests; the engine draws `chunks()`). */
  geometry(): THREE.BufferGeometry {
    const { rows, cols } = this;
    const pos = new Float32Array(rows * cols * 3);
    const uv = new Float32Array(rows * cols * 2);
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const i = r * cols + c;
        pos[i * 3] = this.t.x0 + c * this.t.dx;
        pos[i * 3 + 1] = this.heights[i];
        pos[i * 3 + 2] = this.t.z0 + r * this.t.dz;
        uv[i * 2] = (c + 0.5) / cols;
        uv[i * 2 + 1] = 1 - (r + 0.5) / rows;
      }
    }
    const idx = new Uint32Array((rows - 1) * (cols - 1) * 6);
    let k = 0;
    for (let r = 0; r < rows - 1; r++) {
      for (let c = 0; c < cols - 1; c++) {
        const a = r * cols + c;
        const b = a + 1;
        const d = a + cols;
        const e = d + 1;
        idx[k++] = a;
        idx[k++] = d;
        idx[k++] = b;
        idx[k++] = b;
        idx[k++] = d;
        idx[k++] = e;
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    g.setIndex(new THREE.BufferAttribute(idx, 1));
    g.computeVertexNormals();
    return g;
  }
}

/**
 * The planner's own 1 m walking grid (GET /api/sim/fine.bin): the walk surface the route search takes its grades
 * from, roughness, loose sand and off-limits cells. The 3-D mesh is for the eyes; the physics reads this.
 */
export class WalkGrid {
  readonly rows: number;
  readonly cols: number;
  private h: Uint16Array; // centimetres (height_unit_m), arbitrary zero: only differences are used
  private rough: Uint8Array; // centimetres
  private sandBits: Uint8Array;
  private nogoBits: Uint8Array;

  constructor(
    private m: SimFineMeta,
    buf: ArrayBuffer,
  ) {
    this.rows = m.rows;
    this.cols = m.cols;
    const n = m.rows * m.cols;
    const nb = (n + 7) >> 3;
    if (buf.byteLength !== 3 * n + 2 * nb) throw new Error(`walking grid is ${buf.byteLength} bytes, expected ${3 * n + 2 * nb}`);
    // keep the 16-bit heights as they came (3 MB instead of a 6 MB float copy); copy only on a big-endian machine
    const littleEndian = new Uint8Array(new Uint16Array([1]).buffer)[0] === 1;
    if (littleEndian) this.h = new Uint16Array(buf, 0, n);
    else {
      const dv = new DataView(buf);
      this.h = new Uint16Array(n);
      for (let i = 0; i < n; i++) this.h[i] = dv.getUint16(i * 2, true);
    }
    this.rough = new Uint8Array(buf, 2 * n, n);
    this.sandBits = new Uint8Array(buf, 3 * n, nb);
    this.nogoBits = new Uint8Array(buf, 3 * n + nb, nb);
  }

  private nearest(x: number, z: number): number {
    const c = Math.round((x - this.m.x0) / this.m.dx);
    const r = Math.round((z - this.m.z0) / this.m.dz);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return -1;
    return r * this.cols + c;
  }

  private bit(bits: Uint8Array, i: number): boolean {
    return ((bits[i >> 3] >> (7 - (i & 7))) & 1) === 1;
  }

  /** Walk-surface height (bilinear), metres. */
  heightAt(x: number, z: number): number {
    const c = (x - this.m.x0) / this.m.dx;
    const r = (z - this.m.z0) / this.m.dz;
    const c0 = Math.min(Math.max(Math.floor(c), 0), this.cols - 2);
    const r0 = Math.min(Math.max(Math.floor(r), 0), this.rows - 2);
    const fc = Math.min(Math.max(c - c0, 0), 1);
    const fr = Math.min(Math.max(r - r0, 0), 1);
    const i = r0 * this.cols + c0;
    const top = this.h[i] * (1 - fc) + this.h[i + 1] * fc;
    const bot = this.h[i + this.cols] * (1 - fc) + this.h[i + this.cols + 1] * fc;
    return (top * (1 - fr) + bot * fr) * this.m.height_unit_m;
  }

  /** Grade in degrees from (x, z) one metre along the unit direction (dirX, dirZ); uphill positive. */
  gradeDeg(x: number, z: number, dirX: number, dirZ: number): number {
    return (Math.atan2(this.heightAt(x + dirX, z + dirZ) - this.heightAt(x, z), 1) * 180) / Math.PI;
  }

  roughnessM(x: number, z: number): number {
    const i = this.nearest(x, z);
    return i < 0 ? 0 : this.rough[i] * this.m.rough_unit_m;
  }

  isSand(x: number, z: number): boolean {
    const i = this.nearest(x, z);
    return i >= 0 && this.bit(this.sandBits, i);
  }

  isNoGo(x: number, z: number): boolean {
    const i = this.nearest(x, z);
    return i < 0 || this.bit(this.nogoBits, i);
  }

  /**
   * The flattest walkable spot on a ring `rMin`..`rMax` metres from `from`, at least `clear` metres from every point in
   * `avoid` (stops, the route). Deterministic: the same ground always gives the same spot.
   */
  findQuietSpot(from: { x: number; z: number }, rMin: number, rMax: number, avoid: { x: number; z: number }[], clear: number): { x: number; z: number } | null {
    let best: { x: number; z: number } | null = null;
    let bestScore = Infinity;
    for (let r = 0; r < this.rows; r += 4) {
      for (let c = 0; c < this.cols; c += 4) {
        const x = this.m.x0 + c * this.m.dx;
        const z = this.m.z0 + r * this.m.dz;
        const d = Math.hypot(x - from.x, z - from.z);
        if (d < rMin || d > rMax) continue;
        let ok = true;
        for (let dz = -8; dz <= 8 && ok; dz += 4) for (let dx = -8; dx <= 8 && ok; dx += 4) if (this.isNoGo(x + dx, z + dz)) ok = false;
        if (!ok) continue;
        let near = Infinity;
        for (const a of avoid) near = Math.min(near, Math.hypot(a.x - x, a.z - z));
        if (near < clear) continue;
        const slope = Math.abs(this.heightAt(x + 4, z) - this.heightAt(x - 4, z)) + Math.abs(this.heightAt(x, z + 4) - this.heightAt(x, z - 4));
        const score = slope + this.roughnessM(x, z);
        if (score < bestScore) {
          bestScore = score;
          best = { x, z };
        }
      }
    }
    return best;
  }

  /** For QA: a point inside walkable ground where the walk surface is steeper than `deg`, and the uphill direction. */
  findSteep(deg: number, near: { x: number; z: number }, maxDist = 400): { x: number; z: number; dirX: number; dirZ: number } | null {
    let best: { x: number; z: number; dirX: number; dirZ: number } | null = null;
    let bestD = Infinity;
    for (let r = 1; r < this.rows - 1; r += 2) {
      for (let c = 1; c < this.cols - 1; c += 2) {
        const x = this.m.x0 + c * this.m.dx;
        const z = this.m.z0 + r * this.m.dz;
        const d = Math.hypot(x - near.x, z - near.z);
        if (d > maxDist || d >= bestD || this.isNoGo(x, z)) continue;
        const gx = (this.heightAt(x + 0.5, z) - this.heightAt(x - 0.5, z));
        const gz = (this.heightAt(x, z + 0.5) - this.heightAt(x, z - 0.5));
        const g = Math.hypot(gx, gz);
        if (g === 0) continue;
        const dirX = gx / g;
        const dirZ = gz / g;
        if (this.gradeDeg(x, z, dirX, dirZ) > deg && !this.isNoGo(x + dirX, z + dirZ)) {
          best = { x, z, dirX, dirZ };
          bestD = d;
        }
      }
    }
    return best;
  }
}
