// Easter egg: skateboarding on Mars. Off-plan and unofficial, but the physics is honest: what pulls you downhill is
// g sin(grade) with g = 3.71 m/s², what stops you is rolling resistance on regolith, and the thin air (about 0.02 kg/m³
// at Gale, under 2 % of Earth's) does almost nothing. The rolling-resistance numbers are MarsWalk's assumptions for
// small urethane wheels (see TODO.md: "Skateboard"); everything else is textbook mechanics.

export interface SkateParams {
  crrBase: number; // rolling resistance coefficient on smooth, firm ground
  crrPerRoughM: number; // added per metre of the planner's 1 m roughness: small wheels hate rocks
  crrSand: number; // added on loose sand: wheels sink
  crrMax: number;
  pushForceN: number; // most a suited kick can push (traction is low: only 0.38 g holds your foot down)
  pushPowerW: number; // mechanical power of steady pushing
  brakeDecel: number; // foot drag, m/s² (friction-limited: mu * g = 0.6 * 3.71 = 2.2 at best)
  rhoAir: number; // kg/m³, Gale surface
  cdA: number; // drag area of an upright suited person, m²
  wipeoutMps: number; // speed wobbles past this: you come off
  roughWipeoutMps: number; // on off-limits (rocky or steep) ground, faster than this and you come off
  muscleEff: number; // mechanical to metabolic
  restW: number; // metabolic power at rest (same as the walking model's floor)
}

export const SKATE: SkateParams = {
  crrBase: 0.04,
  crrPerRoughM: 0.3,
  crrSand: 0.25,
  crrMax: 0.8,
  pushForceN: 60,
  pushPowerW: 100,
  brakeDecel: 1.5,
  rhoAir: 0.02,
  cdA: 0.8,
  wipeoutMps: 7,
  roughWipeoutMps: 1.2,
  muscleEff: 0.25,
  restW: 60,
};

export function rollingCoeff(roughM: number, sand: boolean, p: SkateParams = SKATE): number {
  return Math.min(p.crrBase + p.crrPerRoughM * Math.max(roughM, 0) + (sand ? p.crrSand : 0), p.crrMax);
}

export interface SkateStep {
  v: number; // new speed along the board, m/s (negative = rolling backwards)
  a: number; // acceleration this step, m/s²
  powerW: number; // metabolic power this step
}

/**
 * One time step of riding. v is signed speed along the heading; gradeDeg is the slope ahead (uphill positive);
 * push and brake are the W and S keys.
 */
export function skateStep(
  v: number, dt: number, gradeDeg: number, roughM: number, sand: boolean, push: boolean, brake: boolean,
  g: number, massKg: number, p: SkateParams = SKATE,
): SkateStep {
  const th = (gradeDeg * Math.PI) / 180;
  const crr = rollingCoeff(roughM, sand, p);
  const slope = -g * Math.sin(th); // downhill speeds you up
  const rollMax = crr * g * Math.cos(th);
  const pushF = push ? Math.min(p.pushForceN, p.pushPowerW / Math.max(Math.abs(v), 0.1)) : 0;
  const drive = slope + pushF / massKg;
  // standing still: rolling resistance holds the board unless gravity and the push beat it
  if (Math.abs(v) < 1e-3 && Math.abs(drive) <= rollMax) {
    return { v: 0, a: 0, powerW: p.restW + (push ? (pushF * 0.3) / p.muscleEff : 0) };
  }
  const dir = Math.abs(v) < 1e-3 ? Math.sign(drive) : Math.sign(v);
  const drag = (0.5 * p.rhoAir * p.cdA * v * Math.abs(v)) / massKg;
  const braking = brake ? p.brakeDecel : 0;
  let a = drive - dir * (rollMax + braking) - drag;
  let nv = v + a * dt;
  // resistance and brakes stop the board; they never send it backwards
  if (Math.sign(nv) !== dir && Math.abs(slope + pushF / massKg) <= rollMax + braking) {
    nv = 0;
    a = -v / dt;
  }
  const mech = pushF * Math.max(v, 0);
  return { v: nv, a, powerW: p.restW + (push ? Math.max(mech, pushF * 0.3) / p.muscleEff : 0) + (brake ? 30 : 0) };
}

/** Top speed pushing on level ground: where pushing power meets rolling resistance and drag. */
export function flatTopSpeed(roughM: number, sand: boolean, g: number, massKg: number, p: SkateParams = SKATE): number {
  const roll = rollingCoeff(roughM, sand, p) * massKg * g;
  if (p.pushForceN <= roll) return 0;
  // P / v = roll + 0.5 rho CdA v² -> solve by bisection
  let lo = 0.1;
  let hi = 50;
  for (let i = 0; i < 60; i++) {
    const mid = (lo + hi) / 2;
    const f = Math.min(p.pushForceN, p.pushPowerW / mid) - roll - 0.5 * p.rhoAir * p.cdA * mid * mid;
    if (f > 0) lo = mid;
    else hi = mid;
  }
  return lo;
}
