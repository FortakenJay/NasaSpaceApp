// The walk simulator: a crew member on the real Gale terrain, walking at the speed and energy cost the planner
// assumes, under Mars gravity, in the light of the real Sun for the planned morning. Keyboard: W/S walk, A/D turn, Space jump, E work at a stop (or end at the rover),
// T time speed, V camera, H off-limits overlay. Mouse: drag to look around, wheel to zoom.
import * as THREE from 'three';
import { Line2 } from 'three/examples/jsm/lines/Line2.js';
import { LineGeometry } from 'three/examples/jsm/lines/LineGeometry.js';
import { LineMaterial } from 'three/examples/jsm/lines/LineMaterial.js';
import type { SimPhysics, SimSun } from '../api';
import { makeAstronaut, makeRover } from './astronaut';
import { makeAlien, makePerseverance, makeSkateboard } from './eggs';
import { skateStep } from './skate';
import { G_EARTH, metabolicPower, terrainMultiplier, walkSpeed } from './physics';
import type { Terrain, WalkGrid } from './terrain';

export interface SimStop {
  id: string;
  name: string;
  kind: 'start' | 'stop' | 'user';
  x: number;
  z: number;
  workMin: number;
}

export interface SimStatus {
  tS: number; // mission time, seconds since leaving the rover
  walkedM: number;
  energyKj: number;
  x: number;
  z: number;
  lat: number;
  lon: number;
  headingDeg: number; // compass, 0 = north
  gradeDeg: number; // along the walking direction, on the planner's 1 m walk surface
  speedMps: number;
  tooSteep: boolean; // the slope ahead is steeper than a suited walker may take (max_grade_deg)
  terrainMult: number; // planner's slow-down on this ground: (1 + k * roughness) x sand penalty
  roughM: number; // roughness under the boots (m)
  sand: boolean; // loose sand under the boots
  sunAzDeg: number; // the Sun, clockwise from north
  sunElDeg: number; // the Sun above the horizon (negative = below)
  lmstH: number | null; // local mean solar time, hours
  // easter eggs (off-plan: they never change the plan, and the debrief says when they were used)
  eggsFound: string[]; // 'perseverance', 'skateboard'
  nearEgg: 'alien' | 'board' | null;
  skate: { has: boolean; riding: boolean; v: number; distM: number; wipeouts: number };
  message: string | null; // a line to show for a few seconds
  // engine performance (F to show)
  perf: { on: boolean; fps: number; ms: number; calls: number; tris: number; pixelRatio: number; shadowUpdates: number; chunksDrawn: number; chunks: number };
  powerW: number;
  inNoGo: boolean;
  noGoS: number; // seconds spent on off-limits ground
  near: SimStop | null; // stop within reach
  working: { id: string; leftS: number } | null;
  visited: string[];
  timeScale: number;
  reserveBreached: boolean;
  outOfOxygen: boolean;
  finished: boolean;
  camera: 'third' | 'first';
  hazard: boolean;
  paused: boolean;
}

export const TIME_SCALES = [1, 5, 20, 60];
const REACH_M = 8;
const JUMP_MPS = 1.6; // take-off speed of a suited hop: about 0.35 m high and 0.9 s in the air at 3.71 m/s²
const TURN_RAD_S = 1.6;

export class SimEngine {
  readonly status: SimStatus;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private sun: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private skyMat: THREE.ShaderMaterial | null = null;
  private sunDisc: THREE.Mesh;
  private sunDir = new THREE.Vector3(0.5, 0.7, 0.3).normalize();
  private hazardMesh: THREE.Group | null = null;
  private groundChunks: THREE.Mesh[] = [];
  // easter eggs
  percy: ReturnType<typeof makePerseverance> | null = null; // read by QA
  private alien: ReturnType<typeof makeAlien> | null = null;
  private alienSpot: { x: number; z: number } | null = null;
  private board = makeSkateboard();
  private boardSpot = { x: 0, z: 0 };
  private messageUntil = 0;
  private waveUntil = 0;
  // performance: adaptive resolution and shadows drawn only when something changed
  private frameMs: number[] = [];
  private lastAdapt = 0;
  private pixelRatio = 1;
  private maxPixelRatio = 1;
  private shadowKey = '';
  private shadowUpdates = 0;
  private perfT0 = performance.now();
  private perfFrames = 0;
  private tmpA = new THREE.Color();
  private tmpB = new THREE.Color();
  private tmpV = new THREE.Vector3();
  private frustum = new THREE.Frustum();
  private projView = new THREE.Matrix4();
  private beaconStops = new Map<string, SimStop>();
  private astro = makeAstronaut();
  private trail: Line2;
  private trailPts: number[] = [];
  private lineMats: LineMaterial[] = [];
  private beacons = new Map<string, THREE.Mesh>();
  private rings = new Map<string, Line2>();
  private keys = new Set<string>();
  private heading: number; // radians, 0 = north (-z), clockwise
  private y = 0;
  private vy = 0;
  private airborne = false;
  private phase = 0;
  private camYaw = 0;
  private camPitch = 0.32;
  private camDist = 8;
  private raf = 0;
  private last = performance.now();
  private listeners: ((s: SimStatus) => void)[] = [];
  private lastEmit = 0;
  private dragging = false;
  private mass: number;
  private usableS: number;
  private totalS: number;

  constructor(
    private host: HTMLElement,
    private terrain: Terrain,
    private physics: SimPhysics,
    private stops: SimStop[],
    route: { x: number; z: number }[],
    photo: THREE.Texture,
    hazard: THREE.Texture | null,
    private walk: WalkGrid | null = null,
    private sunTrack: SimSun | null = null,
  ) {
    this.mass = physics.body_mass_kg + physics.suit_mass_kg;
    this.totalS = physics.o2_capacity_h * 3600;
    this.usableS = this.totalS * (1 - physics.walkback_reserve_frac);
    const start = stops.find((s) => s.kind === 'start') ?? { x: 0, z: 0 };
    const first = stops.find((s) => s.kind !== 'start') ?? { x: 0, z: -10 };
    this.heading = Math.atan2(first.x - start.x, -(first.z - start.z));
    const px = start.x + 14 * Math.sin(this.heading); // a few steps out of the rover, facing the first stop
    const pz = start.z - 14 * Math.cos(this.heading);
    const ll = terrain.toLatLon(px, pz);
    this.status = {
      tS: 0, walkedM: 0, energyKj: 0, x: px, z: pz, lat: ll.lat, lon: ll.lon, headingDeg: 0, gradeDeg: 0, speedMps: 0,
      tooSteep: false, terrainMult: 1, roughM: 0, sand: false, sunAzDeg: 90, sunElDeg: 45, lmstH: sunTrack?.lmst_h ?? null,
      eggsFound: [], nearEgg: null, skate: { has: false, riding: false, v: 0, distM: 0, wipeouts: 0 }, message: null,
      perf: { on: false, fps: 0, ms: 0, calls: 0, tris: 0, pixelRatio: 1, shadowUpdates: 0, chunksDrawn: 0, chunks: 0 },
      powerW: 0, inNoGo: false, noGoS: 0, near: null, working: null, visited: [], timeScale: 1, reserveBreached: false,
      outOfOxygen: false, finished: false, camera: 'third', hazard: false, paused: false,
    };
    this.y = terrain.heightAt(px, pz);

    // renderer, camera
    this.renderer = new THREE.WebGLRenderer({ antialias: true, preserveDrawingBuffer: true });
    this.maxPixelRatio = Math.min(window.devicePixelRatio, 2);
    this.pixelRatio = this.maxPixelRatio;
    this.renderer.setPixelRatio(this.pixelRatio);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.autoUpdate = false; // redrawn only when the walker, the board or the Sun moved
    this.renderer.info.autoReset = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    host.appendChild(this.renderer.domElement);
    this.camera = new THREE.PerspectiveCamera(60, 1, 0.3, 9000);

    // Mars: butterscotch sky, dust haze, a small pale Sun (0.35° across, two-thirds of Earth's) with a bluish halo
    // that shows when it is low. Where the Sun is comes from the Mars24 track for the planned morning.
    const sky = new THREE.Color(0xd9b38c);
    this.scene.background = sky;
    this.scene.fog = new THREE.FogExp2(0xd6b08a, 0.00042);
    this.scene.add(this.skyDome());
    this.hemi = new THREE.HemisphereLight(0xf0cfa5, 0x5a3a26, 1.1);
    this.scene.add(this.hemi);
    const discR = 7000 * Math.tan(((0.35 / 2) * Math.PI) / 180);
    this.sunDisc = new THREE.Mesh(new THREE.CircleGeometry(discR, 32), new THREE.MeshBasicMaterial({ color: 0xfff6e8, fog: false, depthWrite: false }));
    this.sunDisc.renderOrder = -1;
    this.scene.add(this.sunDisc);
    this.sun = new THREE.DirectionalLight(0xfff1de, 2.4);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -40;
    sc.right = 40;
    sc.top = 40;
    sc.bottom = -40;
    sc.near = 1;
    sc.far = 400;
    this.scene.add(this.sun, this.sun.target);

    // ground
    photo.colorSpace = THREE.SRGBColorSpace;
    photo.anisotropy = this.renderer.capabilities.getMaxAnisotropy();
    // the ground in 64 x 64-cell tiles: tiles outside the view are not drawn (frustum culling)
    const groundMat = new THREE.MeshStandardMaterial({ map: photo, roughness: 0.96, metalness: 0 });
    const hazardMat = hazard
      ? new THREE.MeshBasicMaterial({ map: hazard, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2 })
      : null;
    if (hazardMat) {
      this.hazardMesh = new THREE.Group();
      this.hazardMesh.visible = false;
      this.scene.add(this.hazardMesh);
    }
    for (const geo of terrain.chunks(64)) {
      const ground = new THREE.Mesh(geo, groundMat);
      ground.receiveShadow = true;
      this.groundChunks.push(ground);
      this.scene.add(ground);
      if (hazardMat && this.hazardMesh) this.hazardMesh.add(new THREE.Mesh(geo, hazardMat));
    }
    this.status.perf.chunks = this.groundChunks.length;

    // the planned route, draped on the ground; the trail walked so far
    if (route.length > 1) {
      // the route is a chain of 1 m grid steps; a short moving average draws it as the walker would see it
      const pts: number[] = [];
      const k = 3;
      for (let i = 0; i < route.length; i++) {
        let sx = 0;
        let sz = 0;
        let n = 0;
        for (let j = Math.max(0, i - k); j <= Math.min(route.length - 1, i + k); j++) {
          sx += route[j].x;
          sz += route[j].z;
          n++;
        }
        const x = i === 0 || i === route.length - 1 ? route[i].x : sx / n;
        const z = i === 0 || i === route.length - 1 ? route[i].z : sz / n;
        pts.push(x, terrain.heightAt(x, z) + 0.25, z);
      }
      this.scene.add(this.line(pts, 0x3dd6e8, 3.5, 0.95));
    }
    this.trailPts = [px, this.y + 0.15, pz, px, this.y + 0.15, pz];
    this.trail = this.line(this.trailPts, 0xffffff, 2.5, 0.9);
    this.scene.add(this.trail);

    // stops: light pillars you can see from far away; the rover at the start
    for (const s of stops) {
      const h = terrain.heightAt(s.x, s.z);
      if (s.kind === 'start') {
        const rover = makeRover();
        rover.position.set(s.x, h, s.z);
        rover.rotation.y = -this.heading;
        this.scene.add(rover);
        continue;
      }
      const pillar = new THREE.Mesh(
        new THREE.CylinderGeometry(0.6, 0.6, 70, 20, 1, true),
        new THREE.MeshBasicMaterial({ color: 0xffb030, transparent: true, opacity: 0.3, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }),
      );
      pillar.position.set(s.x, h + 35, s.z);
      this.scene.add(pillar);
      this.beacons.set(s.id, pillar);
      this.beaconStops.set(s.id, s);
      // the reach ring, draped on the ground (a flat disc would cut through a slope)
      const ringPts: number[] = [];
      for (let i = 0; i <= 64; i++) {
        const a = (i / 64) * Math.PI * 2;
        const rx = s.x + REACH_M * Math.cos(a);
        const rz = s.z + REACH_M * Math.sin(a);
        ringPts.push(rx, terrain.heightAt(rx, rz) + 0.15, rz);
      }
      const ring = this.line(ringPts, 0xffd257, 3, 0.85);
      this.rings.set(s.id, ring);
      this.scene.add(ring);
      this.scene.add(this.label(s.id, s.x, h + 12, s.z));
    }

    this.astro.group.position.set(px, this.y, pz);
    this.scene.add(this.astro.group);
    this.placeEggs(start, route);

    this.bindInput();
    this.resize();
    this.loop();
  }

  onStatus(fn: (s: SimStatus) => void): void {
    this.listeners.push(fn);
  }

  setTimeScale(v: number): void {
    this.status.timeScale = v;
    this.emit(true);
  }

  cycleTimeScale(): void {
    const i = TIME_SCALES.indexOf(this.status.timeScale);
    this.setTimeScale(TIME_SCALES[(i + 1) % TIME_SCALES.length]);
  }

  toggleHazard(): void {
    if (this.hazardMesh) this.hazardMesh.visible = !this.hazardMesh.visible;
    this.status.hazard = !!this.hazardMesh?.visible;
    this.emit(true);
  }

  toggleCamera(): void {
    this.status.camera = this.status.camera === 'third' ? 'first' : 'third';
    this.astro.group.visible = this.status.camera === 'third';
    this.emit(true);
  }

  setPaused(p: boolean): void {
    this.status.paused = p;
    this.keys.clear();
    this.emit(true);
  }

  /** E: start work at the stop in reach, or end the walk at the rover. */
  act(): void {
    const s = this.status;
    if (s.working || s.finished || s.outOfOxygen) return;
    if (s.nearEgg === 'alien') {
      if (!s.eggsFound.includes('perseverance')) s.eggsFound = [...s.eggsFound, 'perseverance'];
      this.waveUntil = performance.now() + 4000;
      this.say('The alien lowers the cardboard Mars and waves. Perseverance keeps shooting. (It is officially near Jezero crater, about 3,800 km from here.)', 9000);
      this.emit(true);
      return;
    }
    if (s.nearEgg === 'board' && !s.skate.has) {
      s.skate = { ...s.skate, has: true };
      if (!s.eggsFound.includes('skateboard')) s.eggsFound = [...s.eggsFound, 'skateboard'];
      this.say('You found a skateboard. Press B to ride, B again to step off. It is not in the plan.', 7000);
      this.emit(true);
      return;
    }
    if (!s.near) return;
    if (s.near.kind === 'start') {
      if (s.visited.length > 0) {
        s.finished = true;
        s.paused = true;
      }
    } else if (!s.visited.includes(s.near.id)) {
      s.working = { id: s.near.id, leftS: s.near.workMin * 60 };
      if (s.skate.riding) s.skate = { ...s.skate, riding: false, v: 0 }; // step off to work
    }
    this.emit(true);
  }

  jump(): void {
    if (!this.airborne && !this.status.working) {
      this.airborne = true;
      this.vy = JUMP_MPS;
      // energy of the hop: lifting crew + suit, at 25 % muscle efficiency
      const h = (JUMP_MPS * JUMP_MPS) / (2 * this.physics.gravity_mps2);
      this.status.energyKj += (this.mass * this.physics.gravity_mps2 * h) / 0.25 / 1000;
    }
  }

  /** B: step on or off the skateboard (once you have it). */
  toggleSkate(): void {
    const s = this.status;
    if (!s.skate.has || s.working || s.finished || s.outOfOxygen) return;
    s.skate = { ...s.skate, riding: !s.skate.riding, v: 0 };
    this.emit(true);
  }

  togglePerf(): void {
    this.status.perf = { ...this.status.perf, on: !this.status.perf.on };
    this.emit(true);
  }

  private say(text: string, ms: number): void {
    this.status.message = text;
    this.messageUntil = performance.now() + ms;
  }

  /** Teleport for testing and for "skip to the next stop" in a demo. */
  placeAt(x: number, z: number): void {
    this.status.x = x;
    this.status.z = z;
    this.y = this.terrain.heightAt(x, z);
    this.emit(true);
  }

  dispose(): void {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('resize', this.onResize);
    this.renderer.domElement.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointermove', this.onPointerMove);
    this.renderer.domElement.removeEventListener('wheel', this.onWheel);
    this.scene.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry.dispose();
        const m = o.material as THREE.Material | THREE.Material[];
        (Array.isArray(m) ? m : [m]).forEach((x) => x.dispose());
      }
    });
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }

  // --- simulation -------------------------------------------------------------------------------

  private step(dtReal: number): void {
    const s = this.status;
    const p = this.physics;
    if (s.paused || s.finished || s.outOfOxygen) return;
    let left = dtReal * s.timeScale;
    // turning and jumping happen in real time; walking, work and the clock in mission time
    const turn = (this.keys.has('a') || this.keys.has('arrowleft') ? 1 : 0) - (this.keys.has('d') || this.keys.has('arrowright') ? 1 : 0);
    if (!s.working) this.heading -= turn * TURN_RAD_S * dtReal;
    const fwd = (this.keys.has('w') || this.keys.has('arrowup') ? 1 : 0) - (this.keys.has('s') || this.keys.has('arrowdown') ? 1 : 0);
    let moved = false;
    while (left > 1e-6) {
      const dt = Math.min(left, 0.5);
      left -= dt;
      s.tS += dt;
      // the ground under the boots, whatever you are doing
      s.roughM = this.walk ? this.walk.roughnessM(s.x, s.z) : 0;
      s.sand = this.walk ? this.walk.isSand(s.x, s.z) : false;
      s.terrainMult = terrainMultiplier(s.roughM, s.sand, p.roughness_penalty_per_m ?? 0, p.sand_penalty ?? 1);
      if (s.working) {
        s.gradeDeg = 0;
        s.tooSteep = false;
        s.working.leftS -= dt;
        s.energyKj += (p.work_power_w * dt) / 1000;
        s.powerW = p.work_power_w;
        s.speedMps = 0;
        if (s.working.leftS <= 0) {
          s.visited = [...s.visited, s.working.id];
          const b = this.beacons.get(s.working.id);
          if (b) (b.material as THREE.MeshBasicMaterial).color.set(0x3ad07c);
          s.working = null;
        }
        continue;
      }
      if (s.skate.riding) {
        moved = this.skateStepOnce(dt, fwd) || moved;
        continue;
      }
      if (fwd === 0) {
        s.speedMps = 0;
        s.gradeDeg = 0;
        s.tooSteep = false;
        s.powerW = metabolicPower(this.mass, p.gravity_mps2, 0, 0);
        s.energyKj += (s.powerW * dt) / 1000;
        continue;
      }
      // the planner's model, step for step (cost/physics.py edge_time_energy): the grade comes from the 1 m walk
      // surface the route search uses; speed from the grade; rough ground and loose sand stretch the time by the
      // planner's multiplier at the same power; grades past max_grade_deg cannot be walked at all.
      const dirX = Math.sin(this.heading) * fwd;
      const dirZ = -Math.cos(this.heading) * fwd;
      const surf = this.walk ?? this.terrain;
      const h0 = surf.heightAt(s.x, s.z);
      const grade = (Math.atan2(surf.heightAt(s.x + dirX, s.z + dirZ) - h0, 1) * 180) / Math.PI;
      s.gradeDeg = grade;
      s.tooSteep = Math.abs(grade) > p.max_grade_deg;
      if (s.tooSteep) {
        // too steep to take: you stand there, breathing at rest
        s.speedMps = 0;
        s.powerW = metabolicPower(this.mass, p.gravity_mps2, 0, 0);
        s.energyKj += (s.powerW * dt) / 1000;
        continue;
      }
      const vModel = walkSpeed(grade) * (fwd < 0 ? 0.5 : 1); // backwards: half speed
      let v = vModel / s.terrainMult; // along the slope, as the plan times it: hypot(run, climb) / v
      const across = v * Math.cos((grade * Math.PI) / 180); // the part of it that covers ground on the map
      const nx = s.x + dirX * across * dt;
      const nz = s.z + dirZ * across * dt;
      const b = this.terrain.bounds();
      if (nx < b.minX + 2 || nx > b.maxX - 2 || nz < b.minZ + 2 || nz > b.maxZ - 2) {
        v = 0; // edge of the mapped ground
      } else {
        const d = Math.hypot(nx - s.x, nz - s.z, surf.heightAt(nx, nz) - h0); // along the walk surface, like the plan
        s.x = nx;
        s.z = nz;
        s.walkedM += d;
        this.phase += (d / 1.4) * Math.PI;
        moved = true;
      }
      s.speedMps = v;
      s.powerW = v > 0 ? metabolicPower(this.mass, p.gravity_mps2, grade, vModel) : metabolicPower(this.mass, p.gravity_mps2, 0, 0);
      s.energyKj += (s.powerW * dt) / 1000;
      s.inNoGo = (this.walk ?? this.terrain).isNoGo(s.x, s.z);
      if (s.inNoGo) s.noGoS += dt;
    }
    if (fwd === 0 && !s.working && !s.skate.riding) {
      s.inNoGo = (this.walk ?? this.terrain).isNoGo(s.x, s.z);
      s.tooSteep = false;
    }
    this.checkEggs();
    // vertical: Mars gravity, real time
    const ground = this.terrain.heightAt(s.x, s.z);
    if (this.airborne) {
      this.vy -= p.gravity_mps2 * dtReal;
      this.y += this.vy * dtReal;
      if (this.y <= ground) {
        this.y = ground;
        this.airborne = false;
        this.vy = 0;
      }
    } else {
      this.y = ground;
    }
    if (moved && this.trailEnd() > 2) {
      this.trailPts.push(s.x, ground + 0.15, s.z);
      (this.trail.geometry as LineGeometry).setPositions(this.trailPts);
    }
    // reach, oxygen
    s.near = null;
    let best = Infinity;
    for (const st of this.stops) {
      const d = Math.hypot(st.x - s.x, st.z - s.z);
      if (d <= (st.kind === 'start' ? 12 : REACH_M) && d < best) {
        best = d;
        s.near = st;
      }
    }
    s.reserveBreached = s.tS > this.usableS;
    if (s.tS >= this.totalS) {
      s.outOfOxygen = true;
      s.paused = true;
    }
    const ll = this.terrain.toLatLon(s.x, s.z);
    s.lat = ll.lat;
    s.lon = ll.lon;
    s.headingDeg = ((((this.heading * 180) / Math.PI) % 360) + 360) % 360;
    this.astro.animate(this.phase, moved, this.airborne, s.skate.riding);
  }

  /** One mission-time slice on the board: skate.ts physics on the planner's 1 m ground. Returns whether it moved. */
  private skateStepOnce(dt: number, fwd: number): boolean {
    const s = this.status;
    const p = this.physics;
    const sk = s.skate;
    const dirX = Math.sin(this.heading);
    const dirZ = -Math.cos(this.heading);
    const surf = this.walk ?? this.terrain;
    const h0 = surf.heightAt(s.x, s.z);
    const grade = (Math.atan2(surf.heightAt(s.x + dirX, s.z + dirZ) - h0, 1) * 180) / Math.PI;
    const r = skateStep(sk.v, dt, grade, s.roughM, s.sand, fwd > 0, fwd < 0, p.gravity_mps2, this.mass + 3);
    s.gradeDeg = grade;
    s.tooSteep = false;
    s.speedMps = Math.abs(r.v);
    s.powerW = r.powerW;
    s.energyKj += (r.powerW * dt) / 1000;
    let v = r.v;
    const across = v * Math.cos((grade * Math.PI) / 180);
    const nx = s.x + dirX * across * dt;
    const nz = s.z + dirZ * across * dt;
    const b = this.terrain.bounds();
    let moved = false;
    if (nx < b.minX + 2 || nx > b.maxX - 2 || nz < b.minZ + 2 || nz > b.maxZ - 2) {
      v = 0;
    } else if (v !== 0) {
      const d = Math.hypot(nx - s.x, nz - s.z, surf.heightAt(nx, nz) - h0);
      s.x = nx;
      s.z = nz;
      s.walkedM += d;
      sk.distM += d;
      this.phase += d * 0.5;
      moved = true;
    }
    s.inNoGo = surf.isNoGo(s.x, s.z);
    if (s.inNoGo) s.noGoS += dt;
    // wipeouts: speed wobbles, or rocks and ledges at speed
    const wob = Math.abs(v) > 7;
    const rocks = s.inNoGo && Math.abs(v) > 1.2;
    if (wob || rocks) {
      s.skate = { ...sk, riding: false, v: 0, wipeouts: sk.wipeouts + 1 };
      s.speedMps = 0;
      this.say(wob ? `Wiped out: speed wobbles at ${Math.abs(v).toFixed(1)} m/s. In a suit, a fall is how gloves and visors crack.` : 'Wiped out on rocky ground. Small wheels and Mars rocks do not mix.', 7000);
      return moved;
    }
    s.skate = { ...sk, v, distM: sk.distM };
    return moved;
  }

  /** Put the eggs out: the board by the rover, Perseverance and the alien on quiet flat ground off the route. */
  private placeEggs(start: { x: number; z: number }, route: { x: number; z: number }[]): void {
    const side = this.heading + Math.PI / 2; // to the right of the way out, a few steps from the rover
    this.boardSpot = { x: start.x + Math.sin(side) * 6, z: start.z - Math.cos(side) * 6 };
    this.board.position.set(this.boardSpot.x, this.terrain.heightAt(this.boardSpot.x, this.boardSpot.z), this.boardSpot.z);
    this.board.rotation.y = 0.7;
    this.scene.add(this.board);
    if (!this.walk) return;
    const avoid = [...this.stops, ...route.filter((_, i) => i % 10 === 0)];
    const spot = this.walk.findQuietSpot(start, 150, 320, avoid, 90);
    if (!spot) return;
    this.alienSpot = spot;
    const percy = makePerseverance();
    const alien = makeAlien();
    const yaw = Math.atan2(0.5, -1); // any fixed bearing works: the pair faces each other
    const px = spot.x + Math.sin(yaw) * 4.5;
    const pz = spot.z - Math.cos(yaw) * 4.5;
    percy.group.position.set(px, this.terrain.heightAt(px, pz), pz);
    percy.group.rotation.y = -yaw + Math.PI; // front (-z) toward the alien
    alien.group.position.set(spot.x, this.terrain.heightAt(spot.x, spot.z), spot.z);
    alien.group.rotation.y = -yaw; // sign (-z) toward the rover
    this.scene.add(percy.group, alien.group);
    this.scene.updateMatrixWorld(true);
    // the mast camera looks at the picture
    const target = alien.sign.getWorldPosition(this.tmpV.clone());
    percy.head.lookAt(target);
    percy.head.rotateY(Math.PI); // the head's cameras face its -z
    this.percy = percy;
    this.alien = alien;
  }

  /** What egg is in reach, and the alien's little animation. */
  private checkEggs(): void {
    const s = this.status;
    let near: 'alien' | 'board' | null = null;
    if (!s.skate.has && Math.hypot(s.x - this.boardSpot.x, s.z - this.boardSpot.z) < 2.5) near = 'board';
    if (this.alienSpot && Math.hypot(s.x - this.alienSpot.x, s.z - this.alienSpot.z) < 12) near = 'alien';
    s.nearEgg = near;
    if (s.message && performance.now() > this.messageUntil) s.message = null;
  }

  /** The cardboard-Mars alien: antennae bob; it peeks over the sign when you come close; it waves when greeted. */
  private animateEggs(now: number): void {
    const s = this.status;
    this.board.visible = !s.skate.has || s.skate.riding;
    if (s.skate.riding) {
      this.board.position.set(s.x, this.y, s.z);
      this.board.rotation.set(0, -this.heading, 0);
    }
    if (!this.alien || !this.alienSpot) return;
    const d = Math.hypot(s.x - this.alienSpot.x, s.z - this.alienSpot.z);
    const peek = d < 30 ? 1 : 0;
    const a = this.alien;
    a.head.position.y += ((1.62 + peek * 0.33) - a.head.position.y) * 0.08;
    a.head.rotation.z = Math.sin(now / 600) * 0.06;
    if (peek) {
      // turn to look at you
      const dx = s.x - this.alienSpot.x;
      const dz = s.z - this.alienSpot.z;
      const target = -Math.atan2(dx, -dz) - a.group.rotation.y; // local yaw that points the face (-z) at the walker
      const delta = Math.atan2(Math.sin(target - a.head.rotation.y), Math.cos(target - a.head.rotation.y));
      a.head.rotation.y += delta * 0.05;
    } else a.head.rotation.y *= 0.95;
    const waving = now < this.waveUntil;
    a.armR.rotation.z = waving ? -1.9 + Math.sin(now / 120) * 0.4 : -0.24;
    a.armR.rotation.x = waving ? 0 : -0.55;
    a.sign.position.y = waving ? 1.1 : 1.42;
  }

  private trailEnd(): number {
    const n = this.trailPts.length;
    return Math.hypot(this.trailPts[n - 3] - this.status.x, this.trailPts[n - 1] - this.status.z);
  }

  private loop = (): void => {
    this.raf = requestAnimationFrame(this.loop);
    const now = performance.now();
    const dt = Math.min((now - this.last) / 1000, 0.1);
    this.frameMs.push(now - this.last);
    if (this.frameMs.length > 60) this.frameMs.shift();
    this.last = now;
    this.step(dt);
    this.place();
    this.animateEggs(now);
    this.updateShadows();
    this.renderer.render(this.scene, this.camera);
    this.measure(now);
    this.emit(false);
  };

  /** Shadows: redraw the shadow map only when the walker, the board or the Sun has moved (or the alien is animating). */
  private updateShadows(): void {
    const s = this.status;
    const alienNear = this.alienSpot ? Math.hypot(s.x - this.alienSpot.x, s.z - this.alienSpot.z) < 60 : false;
    const key = `${s.x.toFixed(2)},${s.z.toFixed(2)},${this.y.toFixed(2)},${this.heading.toFixed(3)},${s.sunAzDeg.toFixed(2)},${s.sunElDeg.toFixed(2)},${this.phase.toFixed(2)}`;
    if (key !== this.shadowKey || alienNear) {
      this.shadowKey = key;
      this.renderer.shadowMap.needsUpdate = true;
      this.shadowUpdates++;
    }
  }

  /** Frame statistics, and adaptive resolution: drop the pixel ratio when frames run slow, raise it when there is room. */
  private measure(now: number): void {
    const info = this.renderer.info.render;
    this.perfFrames++;
    let drawn = 0;
    // frustum test the same way the renderer does, for the overlay
    if (this.status.perf.on) {
      this.frustum.setFromProjectionMatrix(this.projView.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse));
      for (const m of this.groundChunks) if (m.geometry.boundingSphere && this.frustum.intersectsSphere(m.geometry.boundingSphere)) drawn++;
    }
    if (now - this.perfT0 >= 1000) {
      const avg = this.frameMs.reduce((a, b) => a + b, 0) / Math.max(this.frameMs.length, 1);
      this.status.perf = {
        ...this.status.perf,
        fps: (this.perfFrames * 1000) / (now - this.perfT0),
        ms: avg,
        calls: info.calls,
        tris: info.triangles,
        pixelRatio: this.pixelRatio,
        shadowUpdates: this.shadowUpdates,
        chunksDrawn: this.status.perf.on ? drawn : this.status.perf.chunksDrawn,
      };
      this.perfFrames = 0;
      this.shadowUpdates = 0;
      this.perfT0 = now;
      if (now - this.lastAdapt > 2000 && this.frameMs.length >= 30) {
        let pr = this.pixelRatio;
        if (avg > 24 && pr > 0.6) pr = Math.max(0.6, pr - 0.15); // under ~40 fps: render fewer pixels
        else if (avg < 14 && pr < this.maxPixelRatio) pr = Math.min(this.maxPixelRatio, pr + 0.1); // over ~70 fps: sharpen
        if (pr !== this.pixelRatio) {
          this.pixelRatio = pr;
          this.renderer.setPixelRatio(pr);
          this.resize();
          this.lastAdapt = now;
        }
      }
    }
  }

  private place(): void {
    const s = this.status;
    this.astro.group.position.set(s.x, this.y + (s.skate.riding ? 0.1 : 0), s.z);
    this.astro.group.rotation.y = -this.heading;
    // camera follows the walker; dragging the mouse looks around
    const yaw = this.heading + this.camYaw + (s.skate.riding && s.camera === 'third' ? 0.75 : 0); // see the board side-on
    if (s.camera === 'first') {
      this.camera.position.set(s.x, this.y + 1.7, s.z);
      this.camera.lookAt(this.tmpV.set(s.x + Math.sin(yaw) * 10, this.y + 1.7 - Math.tan(this.camPitch - 0.32) * 10, s.z - Math.cos(yaw) * 10));
    } else {
      const d = this.camDist;
      const cx = s.x - Math.sin(yaw) * d * Math.cos(this.camPitch);
      const cz = s.z + Math.cos(yaw) * d * Math.cos(this.camPitch);
      const cy = Math.max(this.y + 1.2 + Math.sin(this.camPitch) * d, this.terrain.heightAt(cx, cz) + 1.2);
      this.camera.position.set(cx, cy, cz);
      this.camera.lookAt(s.x, this.y + 1.4, s.z);
    }
    // a light pillar fades as you walk up to it, so it marks the stop without blinding you
    for (const [id, pillar] of this.beacons) {
      const st = this.beaconStops.get(id);
      if (!st) continue;
      // a stop you have already worked stays as a dimmer green marker
      const done = s.visited.includes(id) ? 0.5 : 1;
      const ring = this.rings.get(id);
      if (ring) (ring.material as LineMaterial).opacity = done < 1 ? 0.3 : 0.85;
      const d = Math.hypot(st.x - s.x, st.z - s.z);
      (pillar.material as THREE.MeshBasicMaterial).opacity = 0.3 * done * Math.min(Math.max((d - 6) / 60, 0.06), 1);
    }
    this.light();
    this.sun.position.set(s.x + this.sunDir.x * 200, this.y + this.sunDir.y * 200, s.z + this.sunDir.z * 200);
    this.sun.target.position.set(s.x, this.y, s.z);
  }

  /** The Sun at mission time tS, from the Mars24 track (interpolated), as (azimuth, elevation) in degrees. */
  sunAt(tS: number): { az: number; el: number } | null {
    const tr = this.sunTrack;
    if (!tr || tr.az_el.length === 0) return null;
    const f = tS / 60 / tr.step_min;
    const i = Math.min(Math.max(Math.floor(f), 0), tr.az_el.length - 1);
    const j = Math.min(i + 1, tr.az_el.length - 1);
    const w = Math.min(Math.max(f - i, 0), 1);
    const [a0, e0] = tr.az_el[i];
    const [a1, e1] = tr.az_el[j];
    const da = ((((a1 - a0) % 360) + 540) % 360) - 180; // shortest way round
    return { az: (((a0 + da * w) % 360) + 360) % 360, el: e0 + (e1 - e0) * w };
  }

  /** Point the sunlight, the sky and the haze at the Sun's real position for this moment of the walk. */
  private light(): void {
    const s = this.status;
    const sp = this.sunAt(s.tS);
    if (sp) {
      s.sunAzDeg = sp.az;
      s.sunElDeg = sp.el;
      if (this.sunTrack) s.lmstH = (this.sunTrack.lmst_h + (s.tS / 3600) * (24 / 24.6597)) % 24; // Mars hours per Earth hour
    }
    const az = (s.sunAzDeg * Math.PI) / 180;
    const el = (s.sunElDeg * Math.PI) / 180;
    this.sunDir.set(Math.sin(az) * Math.cos(el), Math.sin(el), -Math.cos(az) * Math.cos(el));
    const smooth = (a: number, b: number, x: number) => {
      const u = Math.min(Math.max((x - a) / (b - a), 0), 1);
      return u * u * (3 - 2 * u);
    };
    const day = smooth(-6, 15, s.sunElDeg); // twilight lasts long on Mars: dust scatters light past sunset
    this.sun.intensity = 2.6 * smooth(-0.5, 6, s.sunElDeg);
    this.sun.color.setRGB(1, 0.86 + 0.08 * day, 0.74 + 0.13 * day);
    this.hemi.intensity = 0.12 + 1.0 * day;
    (this.scene.background as THREE.Color).copy(this.tmpA.setHex(0x1e1a24).lerp(this.tmpB.setHex(0xd9b38c), day));
    (this.scene.fog as THREE.FogExp2).color.copy(this.tmpA.setHex(0x1c1820).lerp(this.tmpB.setHex(0xd6b08a), day));
    if (this.skyMat) {
      this.skyMat.uniforms.sunDir.value.copy(this.sunDir);
      this.skyMat.uniforms.day.value = day;
    }
    this.sunDisc.position.copy(this.camera.position).addScaledVector(this.sunDir, 7000);
    this.sunDisc.lookAt(this.camera.position);
    this.sunDisc.visible = s.sunElDeg > -0.5;
  }

  private emit(force: boolean): void {
    const now = performance.now();
    if (!force && now - this.lastEmit < 150) return;
    this.lastEmit = now;
    const snap = { ...this.status };
    for (const fn of this.listeners) fn(snap);
  }

  // --- scenery helpers ---------------------------------------------------------------------------

  private line(pts: number[], color: number, width: number, opacity: number): Line2 {
    const g = new LineGeometry();
    g.setPositions(pts);
    const m = new LineMaterial({ color, linewidth: width, transparent: opacity < 1, opacity, worldUnits: false });
    this.lineMats.push(m);
    return new Line2(g, m);
  }

  private label(text: string, x: number, y: number, z: number): THREE.Sprite {
    const c = document.createElement('canvas');
    c.width = 128;
    c.height = 64;
    const ctx = c.getContext('2d') as CanvasRenderingContext2D;
    ctx.font = '600 44px Barlow, system-ui, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineWidth = 8;
    ctx.strokeStyle = 'rgba(20,14,10,0.85)';
    ctx.strokeText(text, 64, 34);
    ctx.fillStyle = '#ffe2a8';
    ctx.fillText(text, 64, 34);
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), depthTest: false, transparent: true }));
    sp.position.set(x, y, z);
    sp.scale.set(8, 4, 1);
    return sp;
  }

  private skyDome(): THREE.Mesh {
    const m = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        top: { value: new THREE.Color(0xa8714a) },
        horizon: { value: new THREE.Color(0xe8c9a2) },
        night: { value: new THREE.Color(0x15121a) },
        sunDir: { value: this.sunDir.clone() },
        day: { value: 1 },
      },
      vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      // butterscotch by day; around a low Sun the dust scatters blue (the Martian sunset); dark after twilight
      fragmentShader:
        'uniform vec3 top; uniform vec3 horizon; uniform vec3 night; uniform vec3 sunDir; uniform float day; varying vec3 vP;' +
        'void main(){ float t = clamp(vP.y*1.6, 0.0, 1.0); vec3 c = mix(horizon, top, t);' +
        ' float g = pow(max(dot(normalize(vP), sunDir), 0.0), 18.0);' +
        ' float low = 1.0 - smoothstep(0.0, 0.35, sunDir.y);' +
        ' c = mix(c, vec3(0.62, 0.74, 0.86), g * low * 0.85) + vec3(1.0, 0.95, 0.85) * pow(max(dot(normalize(vP), sunDir), 0.0), 400.0) * 0.6;' +
        ' gl_FragColor = vec4(mix(night + vec3(0.25, 0.32, 0.45) * g * 0.6, c, day), 1.0); }',
    });
    this.skyMat = m;
    const dome = new THREE.Mesh(new THREE.SphereGeometry(8000, 32, 16), m);
    dome.onBeforeRender = () => dome.position.copy(this.camera.position);
    return dome;
  }

  // --- input -------------------------------------------------------------------------------------

  private typing(e: Event): boolean {
    const t = e.target as HTMLElement | null;
    return !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
  }

  private onKeyDown = (e: KeyboardEvent): void => {
    if (this.typing(e)) return;
    const k = e.key.toLowerCase();
    if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(k)) {
      this.keys.add(k);
      e.preventDefault();
    } else if (k === ' ') {
      this.jump();
      e.preventDefault();
    } else if (k === 'e') this.act();
    else if (k === 't') this.cycleTimeScale();
    else if (k === 'v') this.toggleCamera();
    else if (k === 'h') this.toggleHazard();
    else if (k === 'b') this.toggleSkate();
    else if (k === 'f') this.togglePerf();
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.key.toLowerCase());
  };

  private onPointerDown = (e: PointerEvent): void => {
    this.dragging = true;
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  private onPointerUp = (): void => {
    this.dragging = false;
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (!this.dragging) return;
    this.camYaw += e.movementX * 0.005;
    this.camPitch = Math.min(Math.max(this.camPitch + e.movementY * 0.004, -0.2), 1.35);
  };

  private onWheel = (e: WheelEvent): void => {
    this.camDist = Math.min(Math.max(this.camDist * (e.deltaY > 0 ? 1.12 : 0.89), 3), 120);
    e.preventDefault();
  };

  private onResize = (): void => this.resize();

  private resize(): void {
    const w = this.host.clientWidth || window.innerWidth;
    const h = this.host.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    for (const m of this.lineMats) m.resolution.set(w, h);
  }

  private bindInput(): void {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('resize', this.onResize);
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown);
    window.addEventListener('pointerup', this.onPointerUp);
    window.addEventListener('pointermove', this.onPointerMove);
    this.renderer.domElement.addEventListener('wheel', this.onWheel, { passive: false });
  }

  /** Press or release a movement key from on-screen controls (and in tests). */
  setKey(key: string, down: boolean): void {
    if (down) this.keys.add(key);
    else this.keys.delete(key);
  }

  /** G_EARTH re-exported for the HUD's "0.38 g". */
  static readonly gEarth = G_EARTH;
}
